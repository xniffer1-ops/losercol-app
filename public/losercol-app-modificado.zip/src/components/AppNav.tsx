"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

type AccionPermiso =
  | "ver"
  | "crear"
  | "editar"
  | "eliminar"
  | "pdf"
  | "whatsapp"
  | "cerrar"
  | "reabrir"
  | "exportar"
  | "cambiarPassword"
  | "cambiarRol";

type ModuloPermiso =
  | "dashboard"
  | "clientes"
  | "vehiculos"
  | "centros"
  | "tarifas"
  | "servicioRapido"
  | "servicios"
  | "caja"
  | "reportes"
  | "historial"
  | "usuarios"
  | "backup";

type PermisosUsuario = Record<
  ModuloPermiso,
  Partial<Record<AccionPermiso, boolean>>
>;

type Usuario = {
  id: number;
  nombre: string;
  email: string;
  rol: "superadmin" | "admin" | "auxiliar" | "operador";
  permisos?: PermisosUsuario;
} | null;

type NavItem = {
  href: string;
  label: string;
  icon: string;
  // null => visible para cualquier usuario autenticado (ej. Inicio)
  modulo: ModuloPermiso | null;
};

// Rutas donde NO se muestra la barra (públicas / login).
const RUTAS_SIN_NAV = ["/login", "/verificar"];

// Mismo conjunto de módulos que el menú del panel principal, en orden lógico.
const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Inicio", icon: "🏠", modulo: null },
  { href: "/servicio-rapido", label: "Servicio rápido", icon: "➕", modulo: "servicioRapido" },
  { href: "/servicios", label: "Servicios", icon: "📋", modulo: "servicios" },
  { href: "/caja", label: "Caja", icon: "💰", modulo: "caja" },
  { href: "/clientes", label: "Clientes", icon: "👥", modulo: "clientes" },
  { href: "/vehiculos", label: "Vehículos", icon: "🚚", modulo: "vehiculos" },
  { href: "/centros", label: "Centros", icon: "🏭", modulo: "centros" },
  { href: "/tarifas", label: "Tarifas", icon: "🏷️", modulo: "tarifas" },
  { href: "/reportes", label: "Reportes", icon: "📊", modulo: "reportes" },
  { href: "/usuarios", label: "Usuarios", icon: "🔐", modulo: "usuarios" },
  { href: "/historial", label: "Historial", icon: "🕘", modulo: "historial" },
];

function tienePermiso(
  usuario: Usuario,
  modulo: ModuloPermiso | null
): boolean {
  if (!usuario) return false;
  if (modulo === null) return true;
  if (usuario.rol === "superadmin") return true;
  return Boolean(usuario.permisos?.[modulo]?.ver);
}

export default function AppNav() {
  const pathname = usePathname() || "/";
  const [usuario, setUsuario] = useState<Usuario>(null);
  const [cargado, setCargado] = useState(false);

  const rutaSinNav = RUTAS_SIN_NAV.some(
    (ruta) => pathname === ruta || pathname.startsWith(`${ruta}/`)
  );

  useEffect(() => {
    if (rutaSinNav) {
      setCargado(true);
      return;
    }

    let activo = true;

    const cargar = async () => {
      try {
        const res = await fetch("/api/me", { cache: "no-store" });
        if (!res.ok) {
          if (activo) setUsuario(null);
          return;
        }
        const data = await res.json();
        if (activo) setUsuario(data);
      } catch {
        if (activo) setUsuario(null);
      } finally {
        if (activo) setCargado(true);
      }
    };

    void cargar();

    return () => {
      activo = false;
    };
  }, [rutaSinNav, pathname]);

  const cerrarSesion = async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
    } finally {
      window.location.href = "/login";
    }
  };

  // No mostramos la barra en login/verificar ni si no hay sesión.
  if (rutaSinNav || !cargado || !usuario) {
    return null;
  }

  const items = NAV_ITEMS.filter((item) => tienePermiso(usuario, item.modulo));

  const esActivo = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname === href || pathname.startsWith(`${href}/`);
  };

  return (
    <nav style={styles.nav} aria-label="Navegación principal">
      <div style={styles.inner}>
        <Link href="/" style={styles.brand} aria-label="Ir al inicio">
          <span style={styles.brandMark}>L</span>
          <span style={styles.brandText}>LOSERCOL</span>
        </Link>

        <div id="app-nav-links" style={styles.links}>
          {items.map((item) => {
            const activo = esActivo(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={activo ? "page" : undefined}
                style={{
                  ...styles.link,
                  ...(activo ? styles.linkActivo : null),
                }}
              >
                <span aria-hidden="true" style={styles.linkIcon}>
                  {item.icon}
                </span>
                {item.label}
              </Link>
            );
          })}
        </div>

        <div style={styles.right}>
          <span style={styles.userInfo}>
            <strong style={styles.userName}>{usuario.nombre}</strong>
            <span style={styles.userRol}>{usuario.rol}</span>
          </span>
          <button type="button" onClick={cerrarSesion} style={styles.logout}>
            Salir
          </button>
        </div>
      </div>
    </nav>
  );
}

const styles: Record<string, React.CSSProperties> = {
  nav: {
    position: "sticky",
    top: 0,
    zIndex: 50,
    background: "linear-gradient(90deg, #14324f 0%, #1e3a5f 60%, #155e63 100%)",
    borderBottom: "2px solid #f59e0b",
    boxShadow: "0 2px 12px rgba(15,42,68,0.28)",
    fontFamily:
      "var(--font-geist-sans, system-ui, -apple-system, Segoe UI, sans-serif)",
  },
  inner: {
    display: "flex",
    alignItems: "center",
    gap: 16,
    flexWrap: "wrap",
    maxWidth: 1400,
    margin: "0 auto",
    padding: "10px 20px",
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    textDecoration: "none",
    flexShrink: 0,
  },
  brandMark: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: 34,
    height: 34,
    borderRadius: 10,
    background: "linear-gradient(135deg, #f59e0b 0%, #f97316 100%)",
    color: "#ffffff",
    fontWeight: 800,
    fontSize: 18,
    boxShadow: "0 2px 6px rgba(245,158,11,0.4)",
  },
  brandText: {
    color: "#ffffff",
    fontWeight: 800,
    fontSize: 18,
    letterSpacing: 0.5,
  },
  links: {
    display: "flex",
    alignItems: "center",
    gap: 4,
    flexWrap: "wrap",
    flex: 1,
  },
  link: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "8px 12px",
    borderRadius: 8,
    color: "#cbd5e1",
    textDecoration: "none",
    fontSize: 14,
    fontWeight: 600,
    whiteSpace: "nowrap",
    transition: "background-color 0.15s ease, color 0.15s ease",
  },
  linkActivo: {
    backgroundColor: "#0d9488",
    color: "#ffffff",
    boxShadow: "0 2px 6px rgba(13,148,136,0.4)",
  },
  linkIcon: {
    fontSize: 15,
  },
  right: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    flexShrink: 0,
    marginLeft: "auto",
  },
  userInfo: {
    display: "flex",
    flexDirection: "column",
    lineHeight: 1.2,
    textAlign: "right",
  },
  userName: {
    color: "#ffffff",
    fontSize: 13,
  },
  userRol: {
    color: "#94a3b8",
    fontSize: 11,
    textTransform: "capitalize",
  },
  logout: {
    padding: "8px 16px",
    borderRadius: 8,
    border: "none",
    backgroundColor: "#ef4444",
    color: "#ffffff",
    fontWeight: 700,
    fontSize: 13,
    cursor: "pointer",
  },
};
