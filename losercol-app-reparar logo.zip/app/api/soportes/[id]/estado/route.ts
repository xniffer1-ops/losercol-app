import { NextResponse } from "next/server";
import { prisma } from "@/src/lib/prisma";
import { requirePermiso } from "@/src/lib/roles";
import { registrarAccion } from "@/src/lib/historial";

const estadosPermitidos = ["pendiente", "proceso", "terminado", "facturado"];

type Params = {
  params: Promise<{
    id: string;
  }>;
};

export async function PUT(req: Request, { params }: Params) {
  const { denied, user } = await requirePermiso("servicios", "editar");
  if (denied) return denied;

  try {
    const { id } = await params;
    const soporteId = Number(id);

    const body = await req.json();
    const nuevoEstado = String(body.estado || "").trim();

    if (!soporteId || !estadosPermitidos.includes(nuevoEstado)) {
      return NextResponse.json(
        { error: "Estado o soporte inválido" },
        { status: 400 }
      );
    }

    if (nuevoEstado === "facturado" && user?.rol !== "superadmin" && !user?.permisos?.servicios?.editar) {
      return NextResponse.json(
        { error: "No tienes permiso para marcar servicios como facturados" },
        { status: 403 }
      );
    }

    const data: {
      estado: string;
      horaInicio?: Date;
      horaFinal?: Date;
    } = {
      estado: nuevoEstado,
    };

    if (nuevoEstado === "proceso") {
      data.horaInicio = new Date();
    }

    if (nuevoEstado === "terminado") {
      data.horaFinal = new Date();
    }

    const soporte = await prisma.soporte.update({
      where: { id: soporteId },
      data,
      include: {
        cliente: true,
        vehiculo: true,
        centroOperacion: true,
        seccion: true,
        servicios: true,
      },
    });

    await registrarAccion(
      "ACTUALIZAR",
      "Soportes",
      `Cambió estado del soporte ${soporte.numero} a ${nuevoEstado}`
    );

    return NextResponse.json(soporte);
  } catch (error) {
    console.error("Error PUT /api/soportes/[id]/estado:", error);

    return NextResponse.json(
      { error: "Error al actualizar estado del soporte" },
      { status: 500 }
    );
  }
}