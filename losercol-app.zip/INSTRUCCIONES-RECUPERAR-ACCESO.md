# Recuperar acceso a LOSERCOL

Este paquete corrige dos causas comunes del error de login:

1. `JWT_SECRET` corto o no configurado en Vercel.
2. Base de datos Neon con columnas antiguas faltantes (`Usuario.permisos` y `Tarifa.cuentaTonelajeOperativo`).

## Paso 1: configurar JWT_SECRET en Vercel

En tu PC puedes generar un secreto seguro:

```powershell
npm run generar:secret
```

Copia el valor generado y pégalo en:

**Vercel > Proyecto LOSERCOL > Settings > Environment Variables > JWT_SECRET**

Debe tener mínimo 32 caracteres.

## Paso 2: subir estos cambios y redeploy

Sube el proyecto a GitHub o reemplaza los archivos corregidos, y deja que Vercel haga un nuevo deploy.

## Paso 3: aplicar migraciones a Neon

Desde tu PC, en la carpeta del proyecto, con el `.env` apuntando a tu base Neon:

```powershell
npm install
npx prisma generate
npm run prisma:migrate
```

## Paso 4: reparar o crear el usuario de ingreso

Opción recomendada desde tu PC:

```powershell
npm run db:repair-login
```

Por defecto repara/crea este usuario:

```text
soporte@losercol.com
```

El comando mostrará una contraseña temporal. Entra con esa contraseña y luego cámbiala desde Usuarios.

También puedes indicar una contraseña específica antes de correr el comando:

```powershell
$env:LOGIN_EMAIL="soporte@losercol.com"
$env:LOGIN_PASSWORD="TuClaveNueva2026*"
npm run db:repair-login
```

## Opción alternativa desde Vercel/browser

Configura temporalmente estas variables en Vercel:

```text
ADMIN_SETUP_TOKEN=un_token_largo_temporal
ADMIN_SETUP_EMAIL=soporte@losercol.com
ADMIN_SETUP_PASSWORD=TuClaveNueva2026*
```

Haz redeploy y abre:

```text
https://losercol-app.vercel.app/api/setup-admin?token=un_token_largo_temporal
```

Cuando responda `ok: true`, entra a `/login` con `soporte@losercol.com` y la clave nueva.

Después de recuperar el acceso, borra `ADMIN_SETUP_TOKEN` y `ADMIN_SETUP_PASSWORD` de Vercel o cambia sus valores.

## Importante

No subas el archivo `.env` real a GitHub. Solo usa `.env.example` como guía.
