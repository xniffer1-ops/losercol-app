# Parche para habilitar /api/setup-admin

Este parche corrige el error `{"error":"No autorizado"}` al abrir `/api/setup-admin`.

## Archivos que reemplaza/agrega

1. `middleware.ts`
   - Agrega `/api/setup-admin` como ruta pública protegida por `ADMIN_SETUP_TOKEN`.

2. `app/api/setup-admin/route.ts`
   - Crea/repara el usuario administrador usando las variables de Vercel.

## Pasos

1. Copia estos archivos en la raíz del proyecto `losercol-app` respetando las carpetas.
2. En PowerShell, dentro del proyecto:

```powershell
git status
git add middleware.ts app/api/setup-admin/route.ts
git commit -m "habilitar recuperacion segura de admin"
git push
```

3. Espera a que Vercel despliegue y quede en `Ready`.
4. Abre la ruta:

```text
https://losercol-app.vercel.app/api/setup-admin?token=TU_ADMIN_SETUP_TOKEN
```

5. Cuando logres entrar, cambia/elimina `ADMIN_SETUP_TOKEN` y `ADMIN_SETUP_PASSWORD` en Vercel y redeploya.
